Bij deze verbeterd: 

Naam van in onderzoek identificatie van object. 
MES-1 datatype toegevoegd en hergebruikt. 
NEN3610ID per objecttype toegevoegd en gebruikt. 

Het root element is: bagStand in BagvsExtractDeelbestandExtractLvc-2.0.xsd in \lvbag\extract-deelbestand-lvc\v20180601
